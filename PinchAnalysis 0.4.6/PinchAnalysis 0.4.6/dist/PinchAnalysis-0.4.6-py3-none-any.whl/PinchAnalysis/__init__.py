#! /usr/bin/env python
# -*- coding: utf-8 -*-
u"""
Name:
File Name: __init__
Description: 
Category:
Requested Elements:
Requested Elements:
Author: Luis Eduardo Correa Gallego
Created on: 9/10/2018
Last modification: 
Used IDE: PyCharm Professional Edition
"""
from .PinchAnalysis import pinchStream
